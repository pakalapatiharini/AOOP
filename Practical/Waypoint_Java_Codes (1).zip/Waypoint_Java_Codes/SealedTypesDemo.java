// Topic 7: Sealed types (Java 17+)
// sealed + permits lists the only classes allowed to extend the parent.
// final means that child cannot be extended further.

sealed class ParkingSpot
        permits CarParkingSpot, BikeParkingSpot, ElectricParkingSpot {
    public void display() {
        System.out.println("Parking spot");
    }
}

final class CarParkingSpot extends ParkingSpot {}
final class BikeParkingSpot extends ParkingSpot {}
final class ElectricParkingSpot extends ParkingSpot {}

public class SealedTypesDemo {
    public static void main(String[] args) {
        ParkingSpot car = new CarParkingSpot();
        ParkingSpot bike = new BikeParkingSpot();
        ParkingSpot electric = new ElectricParkingSpot();

        car.display();
        bike.display();
        electric.display();

        System.out.println("Only the permitted child classes are allowed.");
    }
}
