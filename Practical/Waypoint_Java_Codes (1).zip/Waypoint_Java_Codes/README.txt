WAYPOINT JAVA CODES
===================

This folder contains separate, runnable Java programs for all topics in the PPT.
Each topic has its own .java file. The programs use simple comments and examples
from the Waypoint parking and booking system.

REQUIREMENT
-----------
Java 17 or later is recommended (SealedTypesDemo uses sealed classes).

HOW TO RUN
----------
1. Open this folder in VS Code.
2. Open the terminal in this folder.
3. Compile one program:
      javac DesignByContract.java
4. Run it:
      java DesignByContract

Repeat with any other filename (without .java).

PROGRAMS
--------
1. DesignByContract.java   - Preconditions, postconditions and invariants
2. LspRespected.java       - Correct use of parent and child classes
3. LspViolation.java       - Example of breaking the LSP
4. LspFix.java             - Fixing the LSP violation with an interface
5. CallerSide.java         - Avoiding instanceof checks in calling code
6. InterfacesDemo.java     - PaymentMethod interface and implementations
7. AbstractClassDemo.java  - Abstract ParkingSpot and different fares
8. SealedTypesDemo.java    - Restricting which classes can extend a class
9. RoleSeamsDemo.java      - Replacing payment implementations using a role

IMPORTANT
---------
Compile and run each file separately. Do not compile all files together because
some examples intentionally use the same domain class names to explain different
concepts independently.
