// Topic 1: Design by Contract
// Preconditions = rules checked before a method runs.
// Postconditions = promises checked after a successful method.
// Invariant = a rule that must remain true for a valid object.

enum SpotStatus { AVAILABLE, OCCUPIED }
enum BookingStatus { PENDING, CONFIRMED }

record CustomerId(int value) {}
record ParkingSpotId(int value) {}
record Money(int amount, String currency) {}

class Booking {
    private BookingStatus status = BookingStatus.PENDING;

    void confirm() {
        status = BookingStatus.CONFIRMED;
    }

    BookingStatus getStatus() {
        return status;
    }
}

class ParkingSpot {
    private SpotStatus status = SpotStatus.AVAILABLE;
    private String vehicleNumber = null;

    void park(String vehicle) {
        // Preconditions: vehicle must be valid and spot must be available.
        if (vehicle == null || vehicle.isBlank()) {
            throw new IllegalArgumentException("Invalid vehicle number");
        }
        if (status == SpotStatus.OCCUPIED) {
            throw new IllegalStateException("Spot is already occupied");
        }

        // Change both fields together to preserve the invariant.
        vehicleNumber = vehicle;
        status = SpotStatus.OCCUPIED;
    }

    SpotStatus getStatus() {
        return status;
    }

    String getVehicleNumber() {
        return vehicleNumber;
    }
}

class Waypoint {
    private final ParkingSpot spot = new ParkingSpot();

    Booking reserve(CustomerId customer, ParkingSpotId spotId,
                    String vehicle, int hours, Money fee) {

        // Preconditions: valid vehicle, positive hours, known spot and positive fee.
        if (customer == null || spotId == null) {
            throw new IllegalArgumentException("Customer and spot ID are required");
        }
        if (vehicle == null || vehicle.isBlank()) {
            throw new IllegalArgumentException("Invalid vehicle number");
        }
        if (hours <= 0) {
            throw new IllegalArgumentException("Hours must be positive");
        }
        if (spotId.value() != 201) {
            throw new IllegalArgumentException("No such parking spot");
        }
        if (fee == null || fee.amount() <= 0) {
            throw new IllegalArgumentException("Fee must be positive");
        }

        // Work: simulate payment, park the vehicle and confirm booking.
        spot.park(vehicle);
        boolean paymentSuccessful = true; // Simulated payment
        Booking booking = new Booking();
        booking.confirm();

        // Postconditions: booking confirmed, payment successful, spot occupied.
        if (!paymentSuccessful
                || booking.getStatus() != BookingStatus.CONFIRMED
                || spot.getStatus() != SpotStatus.OCCUPIED) {
            throw new IllegalStateException("A postcondition was not satisfied");
        }

        return booking;
    }
}

public class DesignByContract {
    public static void main(String[] args) {
        Waypoint waypoint = new Waypoint();

        Booking booking = waypoint.reserve(
                new CustomerId(101),
                new ParkingSpotId(201),
                "TS09AB1234",
                2,
                new Money(5000, "INR")
        );

        System.out.println("Booking status: " + booking.getStatus());
        System.out.println("Expected output: CONFIRMED");
    }
}
