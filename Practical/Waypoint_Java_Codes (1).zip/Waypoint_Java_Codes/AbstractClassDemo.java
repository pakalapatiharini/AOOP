// Topic 6: Abstract classes
// Shared data and common code go in the abstract parent.
// Each child provides its own calculateFare() implementation.

abstract class ParkingSpot {
    protected int spotId;
    protected String location;

    public ParkingSpot(int spotId, String location) {
        this.spotId = spotId;
        this.location = location;
    }

    public void displayDetails() {
        System.out.println("Spot ID: " + spotId);
        System.out.println("Location: " + location);
    }

    abstract double calculateFare(int hours);
}

class CarParkingSpot extends ParkingSpot {
    public CarParkingSpot(int id, String location) {
        super(id, location);
    }

    @Override
    double calculateFare(int hours) {
        return hours * 50.0;
    }
}

class BikeParkingSpot extends ParkingSpot {
    public BikeParkingSpot(int id, String location) {
        super(id, location);
    }

    @Override
    double calculateFare(int hours) {
        return hours * 20.0;
    }
}

public class AbstractClassDemo {
    public static void main(String[] args) {
        ParkingSpot car = new CarParkingSpot(101, "Bachupally");
        ParkingSpot bike = new BikeParkingSpot(102, "Nizampet");

        car.displayDetails();
        System.out.println("Car Fare: " + car.calculateFare(2));

        bike.displayDetails();
        System.out.println("Bike Fare: " + bike.calculateFare(2));
    }
}
