// Topic 2: Liskov Substitution Principle (LSP)
// A child object should work wherever its parent object is expected.

class ParkingSpot {
    public void parkVehicle(String vehicle) {
        System.out.println("Vehicle parked: " + vehicle);
    }
}

class CarParkingSpot extends ParkingSpot {
    @Override
    public void parkVehicle(String vehicle) {
        System.out.println("Car parked: " + vehicle);
    }
}

class BikeParkingSpot extends ParkingSpot {
    @Override
    public void parkVehicle(String vehicle) {
        System.out.println("Bike parked: " + vehicle);
    }
}

public class LspRespected {
    public static void main(String[] args) {
        // Parent-type variables hold child objects.
        ParkingSpot spot1 = new CarParkingSpot();
        ParkingSpot spot2 = new BikeParkingSpot();

        spot1.parkVehicle("TS09CAR1234");
        spot2.parkVehicle("TS09BIKE1234");
    }
}
