// Topic 3: LSP violation
// The parent promises parking, but the child throws an exception instead.

class ParkingSpot {
    public void parkVehicle(String vehicle) {
        System.out.println("Vehicle parked: " + vehicle);
    }
}

class ElectricChargingSpot extends ParkingSpot {
    @Override
    public void parkVehicle(String vehicle) {
        // Wrong: this breaks the behaviour promised by ParkingSpot.
        throw new UnsupportedOperationException(
                "Charging required before parking");
    }
}

public class LspViolation {
    public static void main(String[] args) {
        ParkingSpot spot = new ElectricChargingSpot();

        try {
            spot.parkVehicle("EV123");
        } catch (UnsupportedOperationException e) {
            System.out.println("LSP broken: " + e.getMessage());
        }
    }
}
