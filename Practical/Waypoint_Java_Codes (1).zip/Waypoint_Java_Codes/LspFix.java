// Topic 3: Fixing the LSP violation
// Charging is an extra capability, so put it in a separate interface.

class ParkingSpot {
    public void parkVehicle(String vehicle) {
        System.out.println("Vehicle parked: " + vehicle);
    }
}

interface Chargeable {
    void startCharging();
}

class ElectricChargingSpot extends ParkingSpot implements Chargeable {
    // Normal parking is inherited and still works.
    @Override
    public void startCharging() {
        System.out.println("Charging started");
    }
}

public class LspFix {
    public static void main(String[] args) {
        ElectricChargingSpot electricSpot = new ElectricChargingSpot();
        ParkingSpot spot = electricSpot;

        spot.parkVehicle("EV123");
        electricSpot.startCharging();
    }
}
