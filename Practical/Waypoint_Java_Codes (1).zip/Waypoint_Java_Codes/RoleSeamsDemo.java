// Topic 8: Role seams
// BookingService depends on the PaymentMethod role, not a specific payment class.
// This makes the payment implementation replaceable.

record Money(int amount, String currency) {}

interface PaymentMethod {
    void pay(Money amount);
}

class UPIPayment implements PaymentMethod {
    @Override
    public void pay(Money amount) {
        System.out.println("UPI payment: " + amount.amount()
                + " " + amount.currency());
    }
}

class CardPayment implements PaymentMethod {
    @Override
    public void pay(Money amount) {
        System.out.println("Card payment: " + amount.amount()
                + " " + amount.currency());
    }
}

class BookingService {
    private final PaymentMethod paymentMethod;

    // Constructor injection: the caller supplies the payment implementation.
    public BookingService(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void confirmBooking(Money amount) {
        paymentMethod.pay(amount);
        System.out.println("Booking confirmed");
    }
}

public class RoleSeamsDemo {
    public static void main(String[] args) {
        Money fee = new Money(10000, "INR");

        // Use UPI.
        BookingService upiService =
                new BookingService(new UPIPayment());
        upiService.confirmBooking(fee);

        // Switch to Card without changing BookingService.
        BookingService cardService =
                new BookingService(new CardPayment());
        cardService.confirmBooking(fee);
    }
}
