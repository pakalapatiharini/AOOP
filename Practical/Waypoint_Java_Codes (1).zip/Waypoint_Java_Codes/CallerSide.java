// Topic 4: Caller-side substitutability
// Good callers use the parent abstraction instead of checking child types.

class ParkingSpot {
    public void parkVehicle(String vehicle) {
        System.out.println("Vehicle parked: " + vehicle);
    }
}

class CarParkingSpot extends ParkingSpot {}
class BikeParkingSpot extends ParkingSpot {}

public class CallerSide {
    public static void main(String[] args) {
        ParkingSpot[] spots = {
                new CarParkingSpot(),
                new BikeParkingSpot()
        };

        // One common loop works for every kind of ParkingSpot.
        for (ParkingSpot spot : spots) {
            spot.parkVehicle("TS09AB1234");
        }

        // Avoid repeated instanceof checks for CarParkingSpot/BikeParkingSpot.
    }
}
