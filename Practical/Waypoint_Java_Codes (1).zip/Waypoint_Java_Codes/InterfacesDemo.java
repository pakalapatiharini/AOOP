// Topic 5: Interfaces
// An interface says WHAT a class must do, not HOW it does it.

record Money(int amount, String currency) {}

interface PaymentMethod {
    void pay(Money amount);
}

class UPIPayment implements PaymentMethod {
    @Override
    public void pay(Money amount) {
        System.out.println("Paid using UPI: " + amount.amount()
                + " " + amount.currency());
    }
}

class CardPayment implements PaymentMethod {
    @Override
    public void pay(Money amount) {
        System.out.println("Paid using Card: " + amount.amount()
                + " " + amount.currency());
    }
}

public class InterfacesDemo {
    public static void main(String[] args) {
        PaymentMethod payment = new UPIPayment();
        payment.pay(new Money(5000, "INR"));

        // Same interface variable, different implementation.
        payment = new CardPayment();
        payment.pay(new Money(5000, "INR"));
    }
}
